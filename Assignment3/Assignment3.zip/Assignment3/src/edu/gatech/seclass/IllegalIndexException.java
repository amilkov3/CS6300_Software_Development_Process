package edu.gatech.seclass;

public class IllegalIndexException extends RuntimeException {
}
